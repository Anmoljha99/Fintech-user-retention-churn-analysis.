# FinTech User Retention & Churn Analysis

> A data analytics project simulating real-world product analysis work — identifying churn patterns, engagement drop-offs, and proposing data-driven product interventions for a FinTech mobile app.

---

## Table of Contents
- [Project Overview](#project-overview)
- [Key Metrics](#key-metrics)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Analysis & Charts](#analysis--charts)
- [SQL Queries](#sql-queries)
- [Product Recommendations](#product-recommendations)
- [How to Run](#how-to-run)
- [Author](#author)

---

## Project Overview

This project explores how **1,000 simulated users** behave over a **30-day period** in a fictional FinTech mobile app (think Groww, Zerodha, or Revolut). The goal is to:

- Identify **drop-off points** in the user journey
- Segment users by **platform** (iOS/Android) and **plan type** (Free/Trial/Paid)
- Measure **daily active users**, **retention curves**, and **churn rates**
- Propose **product interventions** backed by data

This mirrors the type of analysis a **Product Analyst or Associate Product Manager** would do in a growth or retention team.

---

## Key Metrics

| Metric | Value |
|---|---|
| Total Users | 1,000 |
| Overall Churn Rate | ~55% |
| Avg Daily Active Users | ~322 |
| Highest Churn Segment | Free Plan Users |
| Most Used Feature | Login / View Dashboard |
| Least Used Feature | Invest |

---

## Tech Stack

| Tool | Purpose |
|---|---|
| Python (Pandas) | Data loading, transformation, aggregation |
| Python (Seaborn / Matplotlib) | Data visualization |
| SQL (SQLite-compatible) | Churn table creation, segmentation queries |
| CSV | Simulated dataset |

---

## Project Structure

```
fintech-user-retention-churn-analysis/
│
├── fintech_churn_analysis.py       # Main Python analysis script
├── fintech_user_retention.sql      # All SQL queries (10 queries)
│
├── users.csv                       # User profiles (1,000 users)
├── user_activity.csv               # 30-day activity log (~29K rows)
├── churn_summary.csv               # Per-user churn summary
│
├── charts/
│   ├── 01_dau.png                  # Daily Active Users trend
│   ├── 02_churn_by_platform.png    # Churn rate: iOS vs Android
│   ├── 03_churn_by_plan.png        # Churn rate: Free vs Trial vs Paid
│   ├── 04_retention_curve.png      # Retention curve (day since signup)
│   ├── 05_feature_usage.png        # Feature usage distribution
│   ├── 06_retained_vs_churned.png  # Stacked % by plan type
│   └── 07_session_duration.png     # Avg session duration by plan
│
├── requirements.txt
└── README.md
```

---

## Analysis & Charts

### 1. Daily Active Users (DAU)
Tracks unique users active each day across the 30-day window.

![DAU](charts/01_dau.png)

---

### 2. Churn Rate by Platform
Compares churn between iOS and Android users to detect platform-level issues.

![Churn by Platform](charts/02_churn_by_platform.png)

---

### 3. Churn Rate by Plan Type
Free plan users churn at the highest rate (~65%), while Paid users are most retained.

![Churn by Plan](charts/03_churn_by_plan.png)

---

### 4. User Retention Curve
Shows what % of users remain active N days after signup — a classic product health metric.

![Retention Curve](charts/04_retention_curve.png)

---

### 5. Feature Usage Distribution
Login and View Dashboard dominate usage. The Invest feature is significantly underutilized.

![Feature Usage](charts/05_feature_usage.png)

---

### 6. Retained vs Churned by Plan Type
Stacked bar showing the proportion of retained vs churned users per plan.

![Retained vs Churned](charts/06_retained_vs_churned.png)

---

### 7. Avg Session Duration by Plan Type
Paid users spend more time per session — indicating higher intent and engagement.

![Session Duration](charts/07_session_duration.png)

---

## SQL Queries

The `fintech_user_retention.sql` file contains 10 production-ready queries:

| # | Query |
|---|---|
| 1 | Build `churn_summary` table with LEFT JOIN |
| 2 | Overall churn rate |
| 3 | Churn rate by platform |
| 4 | Churn rate by plan type |
| 5 | Daily Active Users (DAU) |
| 6 | Feature usage with % share (window function) |
| 7 | Avg session duration by plan |
| 8 | Retention by day since signup |
| 9 | High-risk users for re-engagement campaign |
| 10 | Platform × Plan churn cross-tab |

---

## Product Recommendations

Based on the analysis, here are actionable product interventions:

| Segment | Insight | Recommendation |
|---|---|---|
| Free Users | ~65% churn rate, avg 3-5 active days | Trigger onboarding nudges on Day 3 and Day 7 with value highlights |
| Trial Users | Drop off at mid-period (~Day 10) | Send upgrade prompt at Day 10 with limited-time offer |
| All Users | "Invest" feature barely used | Surface investment CTA on home screen / onboarding flow |
| Paid Users | Longest sessions, lowest churn | Introduce loyalty rewards to maintain and deepen engagement |
| Android Users | Slightly higher churn than iOS | Investigate Android-specific UX bugs or performance issues |

---

## How to Run

**1. Clone the repo**
```bash
git clone https://github.com/Anmoljha99/Fintech-user-retention-churn-analysis.
cd Fintech-user-retention-churn-analysis.
```

**2. Install dependencies**
```bash
pip install -r requirements.txt
```

**3. Run the analysis**
```bash
python fintech_churn_analysis.py
```

Charts will be saved in the `charts/` folder.

**4. Run SQL queries**

Open `fintech_user_retention.sql` in any SQLite-compatible client (DB Browser, DBeaver, or run via Python's `sqlite3` module).

---

## Author

**Anmol Jha**
B.Tech ECE — IIIT Ranchi | Product & Data Analytics Enthusiast

- Portfolio: [anmol-rust.vercel.app](https://anmol-rust.vercel.app/)
- GitHub: [github.com/Anmoljha99](https://github.com/Anmoljha99)
- LinkedIn: [linkedin.com/in/anmol-jha99](https://linkedin.com/in/anmol-jha99)
