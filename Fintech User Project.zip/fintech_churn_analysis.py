"""
FinTech User Retention & Churn Analysis
========================================
Analyzes 30-day activity logs of 1,000 simulated users from a FinTech mobile app.
Identifies churn patterns, drop-off points, and proposes product interventions.

Author : Anmol Jha
GitHub : https://github.com/Anmoljha99
"""

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import os

# ── Configuration ──────────────────────────────────────────────────────────────
CHARTS_DIR = "charts"
os.makedirs(CHARTS_DIR, exist_ok=True)

PALETTE = {
    "primary": "#2563EB",
    "danger":  "#EF4444",
    "success": "#10B981",
    "warning": "#F59E0B",
    "purple":  "#8B5CF6",
    "gray":    "#6B7280",
}
PLAN_COLORS = {"Free": PALETTE["danger"], "Trial": PALETTE["warning"], "Paid": PALETTE["success"]}
BG = "#F8FAFC"

sns.set_theme(style="whitegrid", font_scale=1.05)
plt.rcParams.update({
    "figure.facecolor": BG,
    "axes.facecolor": BG,
    "axes.spines.top": False,
    "axes.spines.right": False,
})

# ── Load Data ──────────────────────────────────────────────────────────────────
print("Loading data...")
users    = pd.read_csv("users.csv",         parse_dates=["signup_date"])
activity = pd.read_csv("user_activity.csv", parse_dates=["activity_date"])
churn    = pd.read_csv("churn_summary.csv", parse_dates=["signup_date", "last_active_date"])

print(f"  Users:           {len(users):,}")
print(f"  Activity rows:   {len(activity):,}")
print(f"  Churn records:   {len(churn):,}")

# ── Key Metrics Summary ────────────────────────────────────────────────────────
total_churned   = churn["churned"].sum()
overall_churn   = churn["churned"].mean() * 100
avg_days_active = churn["days_active"].mean()

print("\n========================================")
print("         KEY METRICS SUMMARY")
print("========================================")
print(f"  Total Users         : {len(users):,}")
print(f"  Churned Users       : {total_churned:,}")
print(f"  Overall Churn Rate  : {overall_churn:.1f}%")
print(f"  Avg Days Active     : {avg_days_active:.1f} days")
print(f"  Avg DAU             : {activity.groupby('activity_date')['user_id'].nunique().mean():.0f}")
print("========================================\n")

# ── Chart 1: Daily Active Users ────────────────────────────────────────────────
dau = activity.groupby("activity_date")["user_id"].nunique().reset_index(name="DAU")

fig, ax = plt.subplots(figsize=(12, 4))
ax.fill_between(dau["activity_date"], dau["DAU"], alpha=0.15, color=PALETTE["primary"])
sns.lineplot(data=dau, x="activity_date", y="DAU", marker="o",
             color=PALETTE["primary"], linewidth=2.2, ax=ax)
ax.set_title("Daily Active Users (DAU) — 30-Day Window", fontsize=14, fontweight="bold", pad=12)
ax.set_xlabel("Date")
ax.set_ylabel("Unique Active Users")
plt.xticks(rotation=35, ha="right")
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/01_dau.png", dpi=150)
plt.close()

# ── Chart 2: Churn Rate by Platform ───────────────────────────────────────────
platform_churn = churn.groupby("platform")["churned"].mean().reset_index(name="churn_rate")
colors = [PALETTE["danger"] if r > 0.4 else PALETTE["primary"] for r in platform_churn["churn_rate"]]

fig, ax = plt.subplots(figsize=(6, 4))
bars = ax.bar(platform_churn["platform"], platform_churn["churn_rate"] * 100,
              color=colors, width=0.45, edgecolor="white", linewidth=1.5)
for bar, val in zip(bars, platform_churn["churn_rate"] * 100):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.8,
            f"{val:.1f}%", ha="center", va="bottom", fontweight="bold", fontsize=11)
ax.set_title("Churn Rate by Platform", fontsize=14, fontweight="bold", pad=12)
ax.set_ylabel("Churn Rate (%)")
ax.set_ylim(0, 80)
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/02_churn_by_platform.png", dpi=150)
plt.close()

# ── Chart 3: Churn Rate by Plan Type ──────────────────────────────────────────
plan_churn = churn.groupby("plan_type")["churned"].mean().reset_index(name="churn_rate")
plan_churn = plan_churn.sort_values("churn_rate", ascending=False)

fig, ax = plt.subplots(figsize=(7, 4))
bars = ax.bar(plan_churn["plan_type"], plan_churn["churn_rate"] * 100,
              color=[PLAN_COLORS[p] for p in plan_churn["plan_type"]],
              width=0.45, edgecolor="white", linewidth=1.5)
for bar, val in zip(bars, plan_churn["churn_rate"] * 100):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.8,
            f"{val:.1f}%", ha="center", va="bottom", fontweight="bold", fontsize=11)
ax.set_title("Churn Rate by Plan Type", fontsize=14, fontweight="bold", pad=12)
ax.set_ylabel("Churn Rate (%)")
ax.set_ylim(0, 90)
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/03_churn_by_plan.png", dpi=150)
plt.close()

# ── Chart 4: User Retention Curve ─────────────────────────────────────────────
act_merged = activity.merge(users[["user_id", "signup_date"]], on="user_id")
act_merged["day_since_signup"] = (act_merged["activity_date"] - act_merged["signup_date"]).dt.days
act_merged = act_merged[act_merged["day_since_signup"] >= 0]

retention = (
    act_merged.groupby("day_since_signup")["user_id"]
    .nunique()
    .reset_index(name="retention_count")
)
retention["retention_rate"] = retention["retention_count"] / len(users) * 100

fig, ax = plt.subplots(figsize=(12, 4))
ax.fill_between(retention["day_since_signup"], retention["retention_rate"],
                alpha=0.12, color=PALETTE["success"])
sns.lineplot(data=retention, x="day_since_signup", y="retention_rate",
             color=PALETTE["success"], linewidth=2.2, ax=ax)
ax.set_title("User Retention Curve (Days Since Signup)", fontsize=14, fontweight="bold", pad=12)
ax.set_xlabel("Day Since Signup")
ax.set_ylabel("% Users Still Active")
ax.set_ylim(0, 100)
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/04_retention_curve.png", dpi=150)
plt.close()

# ── Chart 5: Feature Usage Distribution ───────────────────────────────────────
feature_usage = (
    activity.groupby("action_type")
    .size()
    .reset_index(name="count")
    .sort_values("count", ascending=True)
)

fig, ax = plt.subplots(figsize=(8, 5))
bars = ax.barh(feature_usage["action_type"], feature_usage["count"],
               color=sns.color_palette("Blues_d", len(feature_usage)), edgecolor="white")
for bar, val in zip(bars, feature_usage["count"]):
    ax.text(bar.get_width() + 50, bar.get_y() + bar.get_height() / 2,
            f"{val:,}", va="center", fontsize=9)
ax.set_title("Feature Usage Distribution", fontsize=14, fontweight="bold", pad=12)
ax.set_xlabel("Total Actions")
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/05_feature_usage.png", dpi=150)
plt.close()

# ── Chart 6: Retained vs Churned by Plan (Stacked %) ──────────────────────────
stacked = churn.groupby(["plan_type", "churned"]).size().unstack(fill_value=0)
stacked.columns = ["Retained", "Churned"]
stacked_pct = stacked.div(stacked.sum(axis=1), axis=0) * 100

fig, ax = plt.subplots(figsize=(7, 4))
stacked_pct.plot(kind="bar", stacked=True, ax=ax,
                 color=[PALETTE["success"], PALETTE["danger"]],
                 edgecolor="white", width=0.5)
ax.set_title("Retained vs Churned by Plan Type (%)", fontsize=14, fontweight="bold", pad=12)
ax.set_ylabel("% of Users")
ax.set_xlabel("")
ax.legend(loc="upper right")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/06_retained_vs_churned.png", dpi=150)
plt.close()

# ── Chart 7: Avg Session Duration by Plan ─────────────────────────────────────
act_plan = activity.merge(users[["user_id", "plan_type"]], on="user_id")
session = act_plan.groupby("plan_type")["session_duration_min"].mean().reset_index()

fig, ax = plt.subplots(figsize=(6, 4))
bars = ax.bar(session["plan_type"], session["session_duration_min"],
              color=[PLAN_COLORS[p] for p in session["plan_type"]],
              width=0.45, edgecolor="white")
for bar, val in zip(bars, session["session_duration_min"]):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.2,
            f"{val:.1f} min", ha="center", fontweight="bold", fontsize=10)
ax.set_title("Avg Session Duration by Plan Type", fontsize=14, fontweight="bold", pad=12)
ax.set_ylabel("Minutes")
plt.tight_layout()
plt.savefig(f"{CHARTS_DIR}/07_session_duration.png", dpi=150)
plt.close()

print("Analysis complete. All 7 charts saved to /charts/")
print("\nProduct Recommendations:")
print("  1. Free users churn fastest — trigger onboarding nudges on Day 3 & Day 7.")
print("  2. Trial users drop off mid-period — send upgrade prompts at Day 10.")
print("  3. 'login' is most used, 'invest' is least — surface investment features on home screen.")
print("  4. Paid users have longest sessions — introduce loyalty rewards to maintain engagement.")
